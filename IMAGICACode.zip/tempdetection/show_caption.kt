package siddhiyadav363.imagecaptionatgmail.tempdetection

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*



class show_caption : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var labelsList: ArrayList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.show_caption)

        labelsList = intent.getStringArrayListExtra("labelsList") as ArrayList<String>
        database = FirebaseDatabase.getInstance().getReference("IMAGICA")
        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (child in snapshot.children) {
                    val childLabel = child.key.toString()
                    if (labelsList.contains(childLabel)) {
                        // Create a button for the matched label
                        val button = Button(this@show_caption)
                        button.text = childLabel
                        button.setOnClickListener {
                            val intent = Intent(this@show_caption, DisplayCaption::class.java)
                            intent.putExtra("label", childLabel)
                            startActivity(intent)
                        }
                        // Add the button to the layout
                        val layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        )
                        layoutParams.setMargins(0, 10, 0, 10)
                        button.layoutParams = layoutParams
                        findViewById<LinearLayout>(R.id.buttonLayout).addView(button)
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.e("Firebase Database", "Error reading database", error.toException())
            }
        })
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_upload_image, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_logout -> {
                FirebaseAuth.getInstance().signOut()
                val intent = Intent(this@show_caption, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}







