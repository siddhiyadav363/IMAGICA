package siddhiyadav363.imagecaptionatgmail.tempdetection

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.view.Menu
import android.view.MenuItem

import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions


class imageUpload : AppCompatActivity() {

    lateinit var imageView: ImageView
    lateinit var uploadButton: Button
    lateinit var labelButton: Button
    //lateinit var logoutButton: Button
    lateinit var textView: TextView
    lateinit var filePath: Uri
    lateinit var bitmap: Bitmap
    private var labelsList: ArrayList<String> = ArrayList()

    private val PICK_IMAGE_REQUEST = 1234
    lateinit var storage: FirebaseStorage
    lateinit var labeler: ImageLabeler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.upload_image)

        imageView = findViewById(R.id.imageView)
        uploadButton = findViewById(R.id.btn_upload)
        labelButton = findViewById(R.id.btn_next)
        //logoutButton=findViewById(R.id.logout)
        //textView = findViewById(R.id.textview)
        storage = FirebaseStorage.getInstance()
        labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)

        uploadButton.setOnClickListener {
            val intent = Intent()
            intent.type = "image/*"
            intent.action = Intent.ACTION_GET_CONTENT
            startActivityForResult(Intent.createChooser(intent, "Select Image"), PICK_IMAGE_REQUEST)
        }

        labelButton.setOnClickListener {
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            labeler.process(inputImage)
                .addOnSuccessListener { labels ->
                    for (label in labels) {
                        val labelText = label.text
                        val confidence = label.confidence
                        //textView.append("$labelText : $confidence\n")
                        labelsList.add(labelText)
                    }
                    val intent = Intent(this@imageUpload, show_caption::class.java)
                    intent.putStringArrayListExtra("labelsList", labelsList)
                    startActivity(intent)
                }
                .addOnFailureListener { e ->
                    Log.e("Image Labeling Error", "Error occurred while labeling the image", e)
                }
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_upload_image, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_logout -> {
                FirebaseAuth.getInstance().signOut()
                val intent = Intent(this@imageUpload, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            filePath = data.data!!
            try {
                bitmap = MediaStore.Images.Media.getBitmap(contentResolver, filePath)
                imageView.setImageBitmap(bitmap)
                uploadImage()
                labelsList.clear() // clear the previous labels
                //textView.text = "" // clear the previous labels text
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun uploadImage() {
        val ref = storage.reference.child("images/" + System.currentTimeMillis() + ".jpg")
        val uploadTask: UploadTask = ref.putFile(filePath)
        uploadTask.addOnSuccessListener {
            Log.e("Firebase Storage", "Image uploaded successfully")
        }.addOnFailureListener {
            Log.e("Firebase Storage", "Error occurred while uploading the image")
        }
    }
}
