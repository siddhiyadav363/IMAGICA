package siddhiyadav363.imagecaptionatgmail.tempdetection
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.databinding.DataBindingUtil.setContentView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class DisplayCaption:AppCompatActivity() {

    private var counter: Int = 0
    private lateinit var database: DatabaseReference
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.displaycaption)

        database = FirebaseDatabase.getInstance().getReference("IMAGICA")
        findViewById<TextView>(R.id.labelValueTextView).setTextIsSelectable(true)

        displayNext10KeyValues()

        findViewById<Button>(R.id.refreshButton).setOnClickListener {
            displayNext10KeyValues()
        }
    }

    private fun displayNext10KeyValues() {
        val label = intent.getStringExtra("label").toString()
        val selectedLabelRef = database.child(label)

        selectedLabelRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val keyValuesList = ArrayList<String>()
                for (child in snapshot.children) {
                    val key = child.key.toString()
                    val value = child.value.toString()
                    keyValuesList.add("$value")
                }
                val startIndex = counter
                var endIndex = counter + 10
                if (endIndex > keyValuesList.size) {
                    endIndex = keyValuesList.size
                }
                val selectedKeyValues = keyValuesList.subList(startIndex, endIndex)
                val keyValuesTextView = findViewById<TextView>(R.id.labelValueTextView)
                keyValuesTextView.text = selectedKeyValues.joinToString("\n\n")
                counter += 10
                if (counter >= keyValuesList.size) {
                    counter = 0
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("Firebase Database", "Error reading database", error.toException())
            }
        })
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_upload_image, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_logout -> {
                FirebaseAuth.getInstance().signOut()
                val intent = Intent(this@DisplayCaption, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}


